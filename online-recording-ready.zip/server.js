import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import { nanoid } from 'nanoid';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const UPLOAD_DIR = path.join(__dirname, 'uploads');
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'records.json');
const TASKS_FILE = path.join(DATA_DIR, 'tasks.txt');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify([]));
if (!fs.existsSync(TASKS_FILE)) fs.writeFileSync(TASKS_FILE, '');

// Multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '.wav') || '.wav';
    cb(null, `${Date.now()}-${nanoid(6)}${ext}`);
  }
});
const upload = multer({ storage });

// helpers
const readJSON = (p) => JSON.parse(fs.readFileSync(p, 'utf-8'));
const writeJSON = (p, data) => fs.writeFileSync(p, JSON.stringify(data, null, 2));

// API — tasks
app.get('/api/tasks', (req, res) => {
  const txt = fs.readFileSync(TASKS_FILE, 'utf-8');
  const lines = txt.split('\n').map(s=>s.trim()).filter(Boolean);
  res.json({ tasks: lines });
});

app.post('/api/tasks', (req, res) => {
  const { text } = req.body || {};
  if (!text) return res.status(400).json({ ok:false, error: 'No text' });
  fs.writeFileSync(TASKS_FILE, text, 'utf-8');
  const count = text.split('\n').map(s=>s.trim()).filter(Boolean).length;
  res.json({ ok:true, count });
});

// API — upload recording
app.post('/api/recordings', upload.single('file'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ ok:false, error:'No file' });
    const recs = readJSON(DB_FILE);
    const id = nanoid(8);
    const {
      userId = 'demo_user',
      age = '',
      nationality = '',
      prefix = '',
      taskId = '',
      sampleRate = ''
    } = req.body || {};

    // auto numbering for same user/prefix
    const userRecs = recs.filter(r=>r.userId===userId && r.prefix===prefix);
    const nextNum = String(userRecs.length + 1).padStart(3,'0');
    const baseName = prefix ? `${prefix}_${nextNum}` : nextNum;
    const finalName = `${baseName}.wav`;
    const finalPath = path.join(UPLOAD_DIR, finalName);
    fs.renameSync(req.file.path, finalPath);

    const rec = {
      id, userId, age, nationality, prefix, taskId, sampleRate,
      filename: finalName, status: 'pending', comment: '',
      createdAt: Date.now()
    };
    recs.push(rec);
    writeJSON(DB_FILE, recs);
    res.json({ ok:true, id, rec });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false, error:String(e) });
  }
});

// Admin list/filter
app.get('/api/admin/recordings', (req,res)=>{
  const { status='all' } = req.query;
  const recs = readJSON(DB_FILE);
  const items = status==='all' ? recs : recs.filter(r=>r.status===status);
  res.json({ items });
});

// Admin update
app.patch('/api/admin/recordings/:id', (req,res)=>{
  const { id } = req.params;
  const { status, comment='' } = req.body || {};
  const recs = readJSON(DB_FILE);
  const idx = recs.findIndex(r=>r.id===id);
  if (idx===-1) return res.status(404).json({ ok:false, error:'Not found' });
  if (status) recs[idx].status = status;
  recs[idx].comment = comment;
  writeJSON(DB_FILE, recs);
  res.json({ ok:true, rec:recs[idx] });
});

// Download
app.get('/api/recordings/:id/download', (req,res)=>{
  const { id } = req.params;
  const recs = readJSON(DB_FILE);
  const rec = recs.find(r=>r.id===id);
  if (!rec) return res.status(404).send('Not found');
  res.download(path.join(UPLOAD_DIR, rec.filename));
});

// fallback to index
app.get('*', (req,res)=>{
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, ()=> console.log(`Server running on http://localhost:${PORT}`));
