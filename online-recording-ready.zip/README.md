
# Online Recording System — Ready to Run

## Quick Start (Local)
```bash
npm i
npm start
# open http://localhost:3001/
```

## Deploy
- **Frontend & Backend together on Render/Railway/VPS:** just run `node server.js`.
- **Static on Netlify + API on Render:** keep `index.html` as is (relative `/api/...` works if both served on same domain).
  If split, set CORS in `server.js` to allow your Netlify domain.
